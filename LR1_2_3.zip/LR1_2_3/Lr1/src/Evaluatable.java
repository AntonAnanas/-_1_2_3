public interface Evaluatable {
    double evalf (double x);

}
