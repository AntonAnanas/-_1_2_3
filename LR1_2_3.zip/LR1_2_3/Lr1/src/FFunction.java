import edu.hws.jcm.data.Expression;
import edu.hws.jcm.data.Parser;
import edu.hws.jcm.data.Variable;

import java.util.Scanner;

public class FFunction implements Evaluatable{

    private double a;

    public  double evalf(double x){
        return 0;
    }

    public FFunction(double a){
        this.a = a;
    }

    public FFunction(){
        this(1.0);
    }

    public void setA(double a){
        this.a = a;
    }

    public double getA(){
        return a;
    }

    public static void fFun(String func){
        Parser parser = new Parser(Parser.STANDARD_FUNCTIONS);
        Variable var = new Variable("x");
        Variable par = new Variable("a");
        parser.add(var);
        parser.add(par);
        String funStr = func;
        Expression fun = parser.parse(funStr);
        Expression der = fun.derivative(var);
        Scanner in = new Scanner(System.in);
        System.out.println("Параметр a: ");
        double a = in.nextDouble();
        par.setVal(a);
        System.out.print("xBeg: ");
        double xBeg = in.nextDouble();
        System.out.print("xEnd: ");
        double xEnd = in.nextDouble();
        System.out.print("xStep: ");
        double xStep = in.nextDouble();
        for (double x = xBeg; x <= xEnd; x += xStep) {
            var.setVal(x);
            System.out.println("x = " + x + "\t" + fun.getVal() + "\t" + der.getVal());
        }
    }
}
