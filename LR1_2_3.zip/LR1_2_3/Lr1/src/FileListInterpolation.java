import java.io.*;
import java.util.*;

public class FileListInterpolation extends ListInterpolation {

    public FileListInterpolation() {
        super();
    }

    public void readFromFileList(String fileName) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String s;
        while ((s = in.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(s);
            double x = Double.parseDouble(st.nextToken());
            double y = Double.parseDouble(st.nextToken());
            addPointList(new Point2D(x, y));
        }
        in.close();
    }

    public void readFromFileSet(String fileName) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String s;
        while ((s = in.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(s);
            double x = Double.parseDouble(st.nextToken());
            double y = Double.parseDouble(st.nextToken());
            addPointSet(new Point2D(x, y));
        }
        in.close();
    }
    public void readFromFileMap(String fileName) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String s;
        while ((s = in.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(s);
            int i = Integer.parseInt(st.nextToken());
            double x = Double.parseDouble(st.nextToken());
            double y = Double.parseDouble(st.nextToken());
            addPointMap(i, new Point2D(x, y));
        }
        in.close();
    }

    public void writeToFileList(String fileName) throws IOException {
        PrintWriter out = new PrintWriter(new FileWriter(fileName));
        for (int i = 0; i < numPointsList(); i++) {
            out.println(getPointList(i).getX() + "\t" + getPointList(i).getY());
        }
        out.close();
    }
    public void writeToFileSet(String fileName) throws IOException {
        PrintWriter out = new PrintWriter(new FileWriter(fileName));
        for (int i = 1; i <= numPointsSet(); i++) {
            out.println(getPointSet(i).getX() + "\t" + getPointSet(i).getY());
        }
        out.close();
    }
    public void writeToFileMap(String fileName) throws IOException {
        PrintWriter out = new PrintWriter(new FileWriter(fileName));
        for (int i = 0; i < numPointsMap(); i++) {
            out.println(i+ "\t" + getPointMap(i).getX() + "\t" + getPointMap(i).getY());
        }
        out.close();
    }


    public static void interpolateList(){
        FileListInterpolation fun = new FileListInterpolation();
        double x;
        for (double i = 1.5; i < 6.5; i+=0.05) {
            x = i;
            fun.addPointList(new Point2D(x, Math.sin(x)));
        }
        System.out.println("Інтерполяція по: " + fun.numPointsList() + " точкам");
        /*for (int i = 0; i < fun.numPointsList(); i++)
            System.out.println("Точка " + (i) + ": " + fun.getPointList(i));*/
        System.out.println("Мінімальне значення x: " + fun.getPointList(0).getX());
        System.out.println("Максимальне значення x: " +
                fun.getPointList(fun.numPointsList()-1).getX());
        System.out.println("Збереження...");

        try {
            fun.writeToFileList("data.dat");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(-1);
        }

        System.out.println("Зчитування...");
        fun.clear();
        try {
            fun.readFromFileList("data.dat");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(-1);
        }

        System.out.println("Данні з файлу: ");
        for (int i = 1; i < fun.numPointsList(); i++)
            System.out.println("Точка " + (i+1) + ": " + fun.getPointList(i));
        System.out.println("Мінімальне значення x: " + fun.getPointList(0).getX());
        System.out.println("Максимальне значення x: " +
                fun.getPointList(fun.numPointsList()-1).getX());
        x = 0.5*(fun.getPointList(0).getX() +
                fun.getPointList(fun.numPointsList()-1).getX());
        System.out.println("Значення інтерполяції fun(" + x + ") = " +
                fun.evalf(x));
        System.out.println("Точне значення sin(" + x + ") = " + Math.sin(x));
        System.out.println("Абсолютна помилка = " +
                Math.abs(fun.evalf(x)-Math.sin(x)));
    }

    public static void interpolateSet(){
        FileListInterpolation fun = new FileListInterpolation();
        double x;
        for (double i = 1.5; i < 6.5; i+=0.05) {
            x = i;
            fun.addPointSet(new Point2D(x, Math.sin(x)));
        }
        System.out.println("Інтерполяція по: " + (fun.numPointsSet()-1) + " точкам");
        for (int i = 1; i < fun.numPointsSet(); i++)
            System.out.println("Точка " + (i) + ": " + fun.getPointSet(i));
        System.out.println("Мінімальне значення x: " + fun.getPointSet(1).getX());
        System.out.println("Максимальне значення x: " +
                fun.getPointSet(fun.numPointsSet()).getX());
        System.out.println("Збереження...");
        try {
            fun.writeToFileSet("dataSet.dat");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(-1);
        }
        fun.clear();
        System.out.println("Зчитування...");

        try {
            fun.readFromFileSet("dataSet.dat");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(-1);
        }

        System.out.println("Данні з файлу: ");
        /*for (int i = 1; i < fun.numPointsSet(); i++)
            System.out.println("Точка " + (i) + ": " + fun.getPointSet(i));*/
        System.out.println("Мінімальне значення x: " + fun.getPointSet(1).getX());
        System.out.println("Максимальне значення x: " +
                fun.getPointSet(fun.numPointsSet()).getX());
        x = 0.5*(fun.getPointSet(1).getX() +
                fun.getPointSet(fun.numPointsSet()).getX());
        System.out.println("Значення інтерполяції fun(" + x + ") = " +
                fun.evalfSet(x));
        System.out.println("Точне значення sin(" + x + ") = " + Math.sin(x));
        System.out.println("Абсолютна помилка = " +
                Math.abs(fun.evalfSet(x)-Math.sin(x)));
    }

    public static void interpolateMap(){
        FileListInterpolation fun = new FileListInterpolation();
        double x = 0;
        for (double i = 1.5; i < 6.5; i+=0.05) {
            fun.addPointMap((int)x, new Point2D(i, Math.sin(i)));
            x+=1;
        }
        System.out.println("Інтерполяція по: " + fun.numPointsMap() + " точкам");
        for (int i = 0; i < fun.numPointsMap(); i++)
            System.out.println("Точка " + (i) + ": " + fun.getPointMap(i));
        System.out.println("Мінімальне значення x: " + fun.getPointMap(0).getX());
        System.out.println("Максимальне значення x: " +
                fun.getPointMap(fun.numPointsMap()-1).getX());
        System.out.println("Збереження...");

        try {
            fun.writeToFileMap("dataMap.dat");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(-1);
        }

        System.out.println("Зчитування...");
        fun.clear();
        try {
            fun.readFromFileMap("dataMap.dat");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(-1);
        }

        System.out.println("Данні з файлу: ");
        System.out.println("Мінімальне значення x: " + fun.getPointMap(0).getX());
        System.out.println("Максимальне значення x: " +
                fun.getPointMap(fun.numPointsMap()-1).getX());
        x = 0.5*(fun.getPointMap(0).getX() +
                fun.getPointMap(fun.numPointsMap()-1).getX());
        System.out.println("Значення інтерполяції fun(" + x + ") = " +
                fun.evalfMap(x));
        System.out.println("Точне значення sin(" + x + ") = " + Math.sin(x));
        System.out.println("Абсолютна помилка = " +
                Math.abs(fun.evalfMap(x)-Math.sin(x)));
    }
    public double evalfSet(double x) {
        double res = 0.0;
        int numData = numPointsSet();
        double numer, denom;

        for (int k = 1; k <= numData; k++) {
            numer = 1.0;
            denom = 1.0;
            for (int j = 1; j <= numData; j++) {
                if (j != k) {
                    numer = numer * (x - getPointSet(j).getX());
                    denom = denom * (getPointSet(k).getX() - getPointSet(j).getX());
                }
            }
            res = res + getPointSet(k).getY()*numer/denom;
        }
        return res;
    }
    public double evalfMap(double x) {
        double res = 0.0;
        int numData = numPointsMap();
        double numer, denom;

        for (int k = 0; k < numData; k++) { numer = 1.0;
            denom = 1.0;
            for (int j = 0; j < numData; j++) {
                if (j != k) {
                    numer = numer * (x - getPointMap(j).getX());
                    denom = denom * (getPointMap(k).getX() - getPointMap(j).getX());
                }
            }
            res = res + getPointMap(k).getY()*numer/denom;
        }
        return res;
    }
}