public abstract class Interpolator implements Evaluatable{
    abstract public void clear();
    abstract public int numPointsList();
    abstract public int numPointsSet();
    abstract public int numPointsMap();
    abstract public void addPointList(Point2D pt);
    abstract public void addPointSet(Point2D pt);
    abstract public void addPointMap(int x, Point2D y);
    abstract public Point2D getPointList(int i);
    abstract public Point2D getPointSet(int i);
    abstract public Point2D getPointMap(int i);
    abstract public void setPoint(int i, Point2D pt);
    abstract public void removeLastPoint();
    abstract public void sort();

    @Override
    public double evalf(double x) {
        double res = 0.0;
        int numData = numPointsList();
        double numer, denom;

        for (int k = 0; k < numData; k++) { numer = 1.0;
            denom = 1.0;
            for (int j = 0; j < numData; j++) {
                if (j != k) {
                    numer = numer * (x - getPointList(j).getX());
                    denom = denom * (getPointList(k).getX() - getPointList(j).getX());
                }
            }
            res = res + getPointList(k).getY()*numer/denom;
        }

        return res;
    }
}
