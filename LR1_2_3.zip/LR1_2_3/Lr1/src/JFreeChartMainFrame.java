import edu.hws.jcm.data.Expression;
import edu.hws.jcm.data.Parser;
import edu.hws.jcm.data.Variable;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleInsets;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFreeChartMainFrame extends JFrame {

    private JPanel contentPane;
    private JTextField textFieldA;
    private JTextField textFieldSt;
    private JTextField textFieldEnd;
    private JTextField textFieldStep;
    private JTextField textFieldFunc;
    private XYSeries series;
    private XYSeries series1;

    public static void plot(){
        EventQueue.invokeLater(new Runnable() {
        public void run() { try {
            JFreeChartMainFrame frame = new JFreeChartMainFrame();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        }
    });
    }

    public JFreeChartMainFrame() {
        setResizable(true);
        setTitle("Plot");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 450);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);

        JPanel panelFunc = new JPanel();
        contentPane.add(panelFunc, BorderLayout.SOUTH);

        JPanel panelData = new JPanel();
        contentPane.add(panelData, BorderLayout.NORTH);

        JButton newPlot = new JButton("Plot");
        newPlot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double start;
                double end;
                double step;
                double a;
                a = Double.parseDouble(textFieldA.getText());
                start = Double.parseDouble(textFieldSt.getText());
                end = Double.parseDouble(textFieldEnd.getText());
                step = Double.parseDouble(textFieldStep.getText());
                series.clear();
                series1.clear();
                for (double x = start; x < end; x += step) {
                    series.add(x, f(a, x));
                    series1.add(x, fDer(a, x));
                }
            }
        });
        panelFunc.add(newPlot);

        JLabel lblNewLabel = new JLabel("a:"); panelData.add(lblNewLabel);
        textFieldA = new JTextField();
        textFieldA.setText("1.0");
        panelData.add(textFieldA);
        textFieldA.setColumns(5);

        JLabel func = new JLabel("Function:");
        panelData.add(func);
        textFieldFunc = new JTextField();
        textFieldFunc.setText("exp(-x^2)*sin(x)");
        panelData.add(textFieldFunc);
        textFieldFunc.setColumns(10);

        JLabel lblNewLabel2 = new JLabel("start:"); panelFunc.add(lblNewLabel2);
        textFieldSt = new JTextField();
        textFieldSt.setText("1.0");
        panelFunc.add(textFieldSt);
        textFieldSt.setColumns(5);

        JLabel lblNewLabel3 = new JLabel("stop:"); panelFunc.add(lblNewLabel3);
        textFieldEnd = new JTextField();
        textFieldEnd.setText("10.0");
        panelFunc.add(textFieldEnd);
        textFieldEnd.setColumns(5);

        JLabel lblNewLabel4 = new JLabel("step:"); panelFunc.add(lblNewLabel4);
        textFieldStep = new JTextField();
        textFieldStep.setText("0.01");
        panelFunc.add(textFieldStep);
        textFieldStep.setColumns(5);

        JFreeChart chart = createChart();
        ChartPanel chartPanel = new ChartPanel(chart);
        contentPane.add(chartPanel, BorderLayout.CENTER);
    }

    private double f(double a, double x) {
        Parser parser = new Parser(Parser.STANDARD_FUNCTIONS);
        Variable var = new Variable("x");
        Variable par = new Variable("a");
        parser.add(var);
        parser.add(par);
        String funStr = textFieldFunc.getText();
        Expression fun = parser.parse(funStr);
        par.setVal(a);
        var.setVal(x);
        return fun.getVal();
    }
    public double fDer(double a, double x){
        Parser parser = new Parser(Parser.STANDARD_FUNCTIONS);
        Variable var = new Variable("x");
        Variable par = new Variable("a");
        parser.add(var);
        parser.add(par);
        par.setVal(a);
        var.setVal(x);
        String funStr = textFieldFunc.getText();
        Expression fun = parser.parse(funStr);
        Expression der = fun.derivative(var);
        return der.getVal();
    }

    private JFreeChart createChart() {
        series = new XYSeries("Function");
        series1 = new XYSeries("Derivative");
        double start = Double.parseDouble(textFieldSt.getText());
        double stop = Double.parseDouble(textFieldEnd.getText());
        double step = Double.parseDouble(textFieldStep.getText());
        double a = Double.parseDouble(textFieldA.getText());
        for (double x = start; x < stop; x += step) {
            series.add(x, f(a,x));
            series1.add(x, fDer(a,x));
        }

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        dataset.addSeries(series1);

        JFreeChart chart = ChartFactory.createXYLineChart(textFieldFunc.getText(), "X",
                "Y", dataset, PlotOrientation.VERTICAL, true, true,
                false);
        chart.setBackgroundPaint(Color.white);
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setBackgroundPaint(Color.lightGray);
        plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
        plot.setDomainGridlinePaint(Color.white); plot.setRangeGridlinePaint(Color.white);
        return chart;
    }
}