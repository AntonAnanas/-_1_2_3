    import java.util.*;

    public class ListInterpolation extends Interpolator {

        private List<Point2D> data = null;
        private TreeSet<Point2D> data1 = null;
        private TreeMap<Integer, Point2D> data2 = null;

        public ListInterpolation(TreeSet<Point2D> data1) {
            this.data1 = data1;
        }
        public ListInterpolation(TreeMap<Integer, Point2D> data2) {
            this.data2 = data2;
        }
        public ListInterpolation(List<Point2D> data) {
            this.data = data;
        }

        public ListInterpolation() {
            data = new ArrayList<Point2D>();
            data1 = new TreeSet<Point2D>();
            data2 = new TreeMap<Integer, Point2D>();
        }

        public ListInterpolation(Point2D[] data) {
            this();
            for (Point2D pt : data)
                this.data.add(pt);
        }
        @Override
        public void clear() {
        data.clear();
        data1.clear();
        data2.clear();
        }
        @Override
        public int numPointsSet() {
            return data1.size();
        }
        @Override
        public int numPointsMap() {
            return data2.size()-1;
        }

        @Override
        public int numPointsList() {
            return data.size();
        }

        public void addPointList(Point2D pt) {
            data.add(pt);
        }
        public void addPointSet(Point2D pt) {
            data1.add(pt);
        }
        public void addPointMap(int x, Point2D pt) {
            data2.put(x, pt);
        }

        @Override
        public Point2D getPointSet(int i) {
            int x = 0;
            Iterator<Point2D> it = data1.iterator();
            Point2D current = null;
            while(it.hasNext() && x < i) {
                current = it.next();
                x++;
            }
            return current;
        }

        @Override
        public Point2D getPointMap(int i) {
            return data2.get(i);
        }

        @Override
        public Point2D getPointList(int i) {
            return data.get(i);
        }

        @Override
        public void setPoint(int i, Point2D pt) {
        data.set(i, pt);
        }

        @Override
        public void removeLastPoint() {
    data.remove(data.size()-1);
        }

        @Override
        public void sort() {
        java.util.Collections.sort(data);
        }

        public static void main(String[] args) {

            ListInterpolation fun = new ListInterpolation();

            int num;
            double x;
            java.util.Scanner in = new java.util.Scanner(System.in);

            do {
                System.out.print("Количество точек: "); num = in.nextInt();
            } while (num <= 0);

            for (int i = 0; i < num; i++)
            {
                x = 1.0 + (5.0 - 1.0)*Math.random(); fun.addPointList(new Point2D(x, Math.sin(x)));
            }
            System.out.println("Интерполяция по: " + fun.numPointsList() + " точкам"); System.out.println("Несортированный набор: ");
            for (int i = 0; i < fun.numPointsList(); i++) System.out.println("Точка " + (i+1) + ": " + fun.getPointList(i));

            fun.sort(); System.out.println("Отсортированный набор: "); for (int i = 0; i < fun.numPointsList(); i++)
                System.out.println("Точка " + (i+1) + ": " + fun.getPointList(i));

            System.out.println("Минимальное значение x: " + fun.getPointList(0).getX()); System.out.println("Максимальное значение x: " +
                    fun.getPointList(fun.numPointsList()-1).getX());

            x = 0.5*(fun.getPointList(0).getX() + fun.getPointList(fun.numPointsList()- 1).getX());
            System.out.println("Значение интеролляции fun(" + x + ") = " + fun.evalf(x));
            System.out.println("Точное значение sin(" + x + ") = " + Math.sin(x)); System.out.println("Абсолютная ошибка = " +
                    Math.abs(fun.evalf(x)-Math.sin(x)));
        }
    }