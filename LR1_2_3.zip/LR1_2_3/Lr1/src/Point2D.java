import java.io.Serializable;

public class Point2D extends Point implements Comparable<Point2D>, Serializable {
    public Point2D(double x, double y) {
        super(2);
        setCoord(1, x);
        setCoord(2, y);
    }

    public Point2D() {
        this(0, 0);
    }

    public double getX() {
        return getCoord(1);
    }

    public void setX(double x) {
        setCoord(1, x);
    }

    public double getY() {
        return getCoord(2);
    }

    public void setY(double y) {
        setCoord(2, y);
    }

    @Override
    public int compareTo(Point2D pt) {
        return Double.compare(getX(), pt.getX());
    }

    public static void main(String[] args) {
        java.util.List<Point2D> data = new java.util.ArrayList<Point2D>();
        int num;
        double x;
        java.util.Scanner in = new java.util.Scanner(System.in);
        System.out.print("xBeg: ");
        double xBeg = in.nextDouble();
        System.out.print("xEnd: ");
        double xEnd = in.nextDouble();
        System.out.print("xStep: ");
        double xStep = in.nextDouble();
        for (double i = xBeg; i < xEnd; i+=xStep) {
            data.add(new Point2D(i, Math.sin(i)));
        }
        for (Point2D pt : data) System.out.println(pt);
    }
}
