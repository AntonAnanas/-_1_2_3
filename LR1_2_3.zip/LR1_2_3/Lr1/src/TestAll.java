import java.io.IOException;
import java.util.Scanner;

public class TestAll {
    public static void main(String[] args) throws IOException {
        FFunction func1;
        FileListInterpolation func2;
        int x = 0;
        Scanner in = new Scanner(System.in);
        while (x!=4){
            System.out.println("1.Ввести функцію\n2.Побудувати графік\n3.Розв'язати рівняння");
            x = in.nextInt();
            switch (x){
                case 1:
                    System.out.println("1.Задана аналітично\n2.Задана таблично");
                    int y = in.nextInt();
                    if(y == 1){
                        System.out.println("Введіть функцію");
                        String f = in.next();
                        func1 = new FFunction();
                        func1.fFun(f);
                    }
                    if(y==2){
                        func2 = new FileListInterpolation();
                        System.out.println("1. ArrayList\n2.TreeSet\n3.TreeMap");
                        int z = in.nextInt();
                        switch (z){
                            case 1:
                                func2.interpolateList();
                                break;
                            case 2:
                                func2.interpolateSet();
                                break;
                            case 3:
                                func2.interpolateMap();
                        }
                    }
                    break;
                case 2:
                    JFreeChartMainFrame.plot();
                    break;
                case 3:
                    DerivativeApplication.run();
                    break;
                case 4:
                    return;
            }
        }
    }
}
