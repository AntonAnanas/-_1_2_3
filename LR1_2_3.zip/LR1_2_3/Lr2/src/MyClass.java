import java.io.Serializable;

public class MyClass implements Serializable {
    private int number;
    private String name = "default";
       public MyClass(int number, String name) {
        this.number = number;
        this.name = name;
    }
    public MyClass() {
        this.number = 123;
        this.name = "Ann";
    }
    public int getNumber() {
        return number;
    }
    public int setNumber(int number) {
        this.number = number;
        return number;
    }
    public String setName(String name) {
        this.name = name;
        return name;
    }
    private void printData(){
        System.out.println(number + name);
    }
}
