import edu.hws.jcm.data.Expression;
import edu.hws.jcm.data.Parser;
import edu.hws.jcm.data.Variable;

public class NumFunction implements Evaluatable{
    String func;
    public NumFunction (String func){
        this.func = func;
    }
    public double evalf(double x){
        Parser parser = new Parser(Parser.STANDARD_FUNCTIONS);
        Variable var = new Variable("x");
        Variable par = new Variable("a");
        parser.add(var);
        parser.add(par);
        String funStr = func;
        Expression fun = parser.parse(funStr);
        var.setVal(x);
        return fun.getVal();
    }

}
