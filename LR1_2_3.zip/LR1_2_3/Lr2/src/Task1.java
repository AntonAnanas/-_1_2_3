import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        System.out.println("Enter the name of the class");
        Scanner in = new Scanner(System.in);
        String name = in.next();
        MyClass myClass = new MyClass();
        String s = getInfo(name);
        String s1 = getInfo(myClass);
        int c [] =  new int[]{1,2,3};
        String s2 = getInfo(c);
        System.out.println(s);
        System.out.println(s1);
        System.out.println(s2);
        Task1_GUI app = new Task1_GUI();
        app.setVisible(true);
    }
    public static String getInfo(String name){
        String s = null;
        Class<?> myClass = null;
        try {
            myClass = Class.forName(name);
        } catch (ClassNotFoundException e) {
            System.out.println("Class Not Found");
        }
        if(myClass.getPackage()!=null)
            s = myClass.getPackage().toString();
        int mod = myClass.getModifiers();
        s+="\n" + Modifier.toString(mod)+" " + myClass + "\n";
        s+= "extends " + myClass.getSuperclass();
        Class[] i = myClass.getInterfaces();
        s+= "\nInterfaces:\n" + Arrays.asList(i);
        s+="\n\nFields:\n";
        Field[] fields1 = myClass.getDeclaredFields();
        for(Field field : fields1)
            s+=field+ "\n";
        s+="\nConstructors:\n";
        Constructor c[] = myClass.getConstructors();
        for (Constructor constructor : c) {
            s+=constructor+"\n";
        }
        s+="\nMethods:\n";
        Method m[] = myClass.getDeclaredMethods();
        for (Method method : m) {
            s+=method+"\n";
        }
        return s;
    }
    public static String getInfo(Object myClass1){
        String s;
        Class myClass = myClass1.getClass();
        if(myClass.getPackage()!=null)
            s = myClass.getPackage().toString();
        else s = "";
        int mod = myClass.getModifiers();
        s+="\n" + Modifier.toString(mod)+" " + myClass + "\n";
        s+= "extends " + myClass.getSuperclass();
        Class[] i = myClass.getInterfaces();
        s+= "\nInterfaces:\n" + Arrays.asList(i);
        s+="\n\nFields:\n";
        Field[] fields1 = myClass.getDeclaredFields();
        for(Field field : fields1)
            s+=field+ "\n";
        s+="\nConstructors:\n";
        Constructor c[] = myClass.getConstructors();
        for (Constructor constructor : c) {
            s+=constructor+"\n";
        }
        s+="\nMethods:\n";
        Method m[] = myClass.getDeclaredMethods();
        for (Method method : m) {
            s+=method+"\n";
        }
        return s;
    }
    //java.lang.String
}
