import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

    public class Task1_GUI extends JFrame {
        private JButton button = new JButton("Go");
        private JTextField input = new JTextField("", 5);
        private JLabel label = new JLabel("Full name of the class:");
        JTextArea  textArea = new JTextArea ();
        public Task1_GUI() {
            super("Simple Example");
            this.setSize(400, 300);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Container container = this.getContentPane();
            //
            label.setPreferredSize(new Dimension(300, 20));
            JPanel panel = new JPanel();
            container.add(panel, BorderLayout.NORTH);
            panel.add(label);
            panel.add(input);
            panel.setLayout(new GridLayout(1,2,1,5));
            container.add(textArea, BorderLayout.CENTER);
            final JScrollPane scrollPane = new JScrollPane(textArea);
            container.add(scrollPane, BorderLayout.CENTER);
            scrollPane
                    .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            button.addActionListener(new ButtonEventListener());
            container.add(button, BorderLayout.PAGE_END);

            //java.lang.String
        }

        class ButtonEventListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                String message = "";
                message += "Class: " + input.getText() + "\n";
                message += Task1.getInfo(input.getText());
                textArea.setText(message);

            }
        }

        public static void main(String[] args) {
            Task1_GUI app = new Task1_GUI();
            app.setVisible(true);
        }
}
