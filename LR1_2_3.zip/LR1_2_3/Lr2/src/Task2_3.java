import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Task2_3 {
    public static void task2(Object o) throws IllegalAccessException, InvocationTargetException {
        Class<?> myClass = o.getClass();
        System.out.println(o.getClass());
        Field[] fields = myClass.getDeclaredFields();
        for(Field field : fields){
            field.setAccessible(true);
            System.out.println(field + " " + field.get(o).toString());
        }
        System.out.println("\nMethods\n");
        Method m[] = myClass.getMethods();
        for (Method method : m) {
            System.out.println(method);
        }
        System.out.println("Enter the method without parameter:\n");
        Scanner in = new Scanner(System.in);
        String meth = in.next();
        for (Method method : m) {
            if(method.getName().equals(meth))
            System.out.println(method.invoke(o));
        }
    }

    public static void task3(Object myClass1, String name, Object [] param ) throws FunctionNotFoundException, IllegalAccessException, InvocationTargetException {
        Class<?> myClass = myClass1.getClass();
        System.out.println("\nTask3\n");
        Method m[] = myClass.getDeclaredMethods();
        boolean flag = false;
        for (Method method : m) {
            if (method.getName().equals(name)) {
                method.setAccessible(true);
                System.out.println(method.invoke(myClass1, param));
                flag = true;
            }
        }
        if (!flag) {
            throw new FunctionNotFoundException("FunctionNotFoundException!");
        }
    }
    public static void main(String[] args) throws IllegalAccessException, InvocationTargetException, FunctionNotFoundException {
        MyClass myClass = new MyClass();
        task2(myClass);
        Object[] param = new Object[] {568};
        task3(myClass, "setNumber", param);
    }
}

class FunctionNotFoundException extends Exception{
    public FunctionNotFoundException(String message){
        super(message);
    }
}