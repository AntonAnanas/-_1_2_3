import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.IntStream;

public class Task4 {
    public static void main(String[] args) throws IllegalAccessException {
        System.out.println("Mas:");
        List<Integer> list = Arrays.asList(1,2,3);
        Integer[] integers = task4(list, Integer.class);
        System.out.println(myToString(integers));

        List<String> list1 = Arrays.asList("one", "two", "three");
        String[] strings = task4(list1, String.class);
        System.out.println(myToString(strings));

        List<MyClass> list2 = Arrays.asList(new MyClass(456, "Jane"), new MyClass());
        MyClass[] myClasses = task4(list2, MyClass.class);
        System.out.println(myToString(myClasses));

        System.out.println("\nMatrix:");
        List<String[]> matr1 = Arrays.asList(new String[]{"one", "two"}, new String[]{"three"});
        String[][] matrStr = task4_matr(matr1, String.class);
        for(int r = 0; r <matrStr.length; r++) {
            System.out.print(myToString(matrStr[r]));
            System.out.println();
        }
        System.out.println();
        List<MyClass[]> matr2 = Arrays.asList(new MyClass[]{new MyClass(456, "Jane"),
                new MyClass(457, "Ostin")},
        new MyClass[]{new MyClass(111, "Peter")});
        MyClass[][] matrMyClass = task4_matr(matr2, MyClass.class);
        for(int r = 0; r <matrMyClass.length; r++) {
            System.out.print(myToString(matrMyClass[r]));
            System.out.println();
        }
        System.out.println("\nChangeSize");

        Integer[] newIntegers = changeSize(integers, Integer.class, 10);
        System.out.println(myToString(newIntegers));
        MyClass[] newMyClasses = changeSize(myClasses, MyClass.class, 10);
        System.out.println(myToString(newMyClasses));
        System.out.println();
        MyClass[][] newMyClasses1 = changeSize(matrMyClass, MyClass.class, 4, 3);
        for(int r = 0; r <newMyClasses1.length; r++) {
            System.out.print(myToString(newMyClasses1[r]));
            System.out.println();
        }
        System.out.println();
        }

    public static <T> T[] task4(Collection<T> c, Class<T> type) {
            if (c == null) {
                return null;
            }
            Object o = Array.newInstance(type, c.size());
            Iterator<T> iterator = c.iterator();
            IntStream.range(0, c.size())
                    .forEach(i -> Array.set(o, i, iterator.next()));
            T[] ts = (T[]) o;
            return ts;
    }

    public static <T> T[][] task4_matr(Collection<T[]> c, Class<T> type) {
        if (c == null) {
            return null;
        }
        Iterator<T[]> it1 = c.iterator();
        int [] sz = new int[c.size()];
        int k = 0;
        while(it1.hasNext()){
            sz[k] = it1.next().length;
            k++;
        }
        T[][] o = (T[][]) Array.newInstance(type, c.size(), sz[0]);
        ArrayIterator <T> arrayIterator = new ArrayIterator<T>(c);
        Iterator<T> iterator = arrayIterator.iterator();
        for(int i = 0; i<c.size(); i++){
            for(int j = 0; j<sz[i]; j++){
                Array.set(o[i], j, iterator.next());
                if(!iterator.hasNext())
                    break;
            }
        }
        return (T[][])o;
    }

    public static <T> T[] changeSize(T[] arr, Class<T> type, int size) {
        Object o = Array.newInstance(type, size);
        System.arraycopy(arr, 0, o, 0, arr.length);
        T[] ts = (T[]) o;
        return ts;
    }
    public static <T> T[][] changeSize(T[][] arr, Class<T> type, int rows, int cols) {
        T[][] o = (T[][])Array.newInstance(type, rows, cols);
        System.arraycopy(arr, 0, o, 0, arr.length);
        return o;
    }
    public static <T> String myToString(T[] myClasses) throws IllegalAccessException {
        String s = "";
        if(isWrapperType(myClasses.getClass().getComponentType())){
            s = Arrays.toString(myClasses);
        }
        else
        for(int i =0; i< myClasses.length; i++) {
            s+="[ ";
            if(myClasses[i]!=null) {
                Field[] fields = myClasses[i].getClass().getDeclaredFields();
                Object value[] = new Object[fields.length];
                int j = 0;
                for (Field field : fields) {
                    field.setAccessible(true);
                    value[j] = field.get(myClasses[i]);
                    s += value[j] + " ";
                    j++;
                }
                s += "] ";
            }
            else s += "... ] ";
        }
        return s;
    }
    private static final Set<Class<?>> WRAPPER_TYPES = getWrapperTypes();

    public static boolean isWrapperType(Class<?> clazz)
    {
        return WRAPPER_TYPES.contains(clazz);
    }

    private static Set<Class<?>> getWrapperTypes() {
        Set<Class<?>> ret = new HashSet<Class<?>>();
        ret.add(Boolean.class);
        ret.add(Character.class);
        ret.add(Byte.class);
        ret.add(Short.class);
        ret.add(Integer.class);
        ret.add(Long.class);
        ret.add(Float.class);
        ret.add(Double.class);
        ret.add(Void.class);
        ret.add(String.class);
        return ret;
    }
}

class ArrayIterator <T> implements Iterable <T> {

    private final List<T> elements;

    public ArrayIterator(Collection<T[]> array) {
        elements = new LinkedList<>();
        for (T[] array1 : array) {
            elements.addAll(Arrays.asList(array1));
        }
    }

    @Override
    public Iterator<T> iterator() {
        return elements.iterator();
    }

}