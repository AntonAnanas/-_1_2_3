import java.lang.reflect.Proxy;

public class Task5 {
    public static void main(String[] args) {
        NumFunction fun1 = new NumFunction("exp(-2.5*x)*sin(x)");
        NumFunction fun = new NumFunction("x^2");
        Evaluatable e = (Evaluatable) Proxy.newProxyInstance(fun.getClass().getClassLoader(),
                fun.getClass().getInterfaces(), new FunHandler(fun));
        e.evalf(2.0);
        Evaluatable e1 = (Evaluatable) Proxy.newProxyInstance(fun1.getClass().getClassLoader(),
                fun1.getClass().getInterfaces(), new FunHandler(fun1));
        e1.evalf(0.9);
    }
}
