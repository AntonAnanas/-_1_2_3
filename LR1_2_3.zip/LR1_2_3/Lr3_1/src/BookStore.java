import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class BookStore implements Serializable {
    String name;
    transient ArrayList<Book> bookArrayList = new ArrayList<>();
    public BookStore(){
        this.name = "BookStore";
        this.bookArrayList.add(new Book());
    }
    public BookStore(String name, ArrayList<Book>bookArrayList){
        this.name = name;
        this.bookArrayList = bookArrayList;
    }
    public String toString(){
        String s = "Name:\n " + name;
        s+= "\nBooks:\n";
        Iterator<Book> iterator = bookArrayList.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString()+ "\n";
        }
        return s;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public ArrayList<Book> getBookArrayList() {
        return bookArrayList;
    }
    public void setBookArrayList(ArrayList<Book> bookArrayList) {
        this.bookArrayList = bookArrayList;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        out.writeInt(bookArrayList.size());
        for (Book b : bookArrayList) {
            out.writeObject(b.getName());
            out.writeInt(b.getYear());
            out.writeInt(b.getNumber());
            out.writeObject(b.getAuthor().getName());
            out.writeObject(b.getAuthor().getSurname());
        }
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        bookArrayList = new ArrayList<Book>();
        int size = in.readInt();
        for (int i = 0; i < size; i++) {
            Book b = new Book((String)in.readObject(), in.readInt(), in.readInt(),
                    new Author((String) in.readObject(), (String) in.readObject()));
            bookArrayList.add(b);
            }
        }

    public static void main(String[] args) {
        BookStore bookStores = new BookStore();
        Serialization.serializeObject("file2.dat", bookStores);
        BookStore bookStores1 = (BookStore) Serialization.deSerializeObject("file2.dat");
        System.out.println("-------------------------------------------------------\nAfter deserialization:");
        System.out.println(bookStores1.toString());
    }

}
