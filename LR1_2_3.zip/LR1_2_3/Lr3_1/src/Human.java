import java.io.Serializable;

public abstract class Human{
    String name;
    String surname;
}
