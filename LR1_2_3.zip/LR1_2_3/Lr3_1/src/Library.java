import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class Library implements Serializable {
    String name;
    transient ArrayList<BookStore> bookStores;
    transient ArrayList<BookReader> bookReaders;
    public Library(String name){
        this.name = name;
        this.bookStores = new ArrayList<>();
        this.bookReaders = new ArrayList<>();
    }
    public Library(String name, ArrayList<BookReader> bookReaders, ArrayList<BookStore> bookStores){
        this.bookReaders = bookReaders;
        this.bookStores = bookStores;
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public ArrayList<BookReader> getBookReaders() {
        return bookReaders;
    }
    public void setBookReaders(ArrayList<BookReader> bookReaders) {
        this.bookReaders = bookReaders;
    }
    public ArrayList<BookStore> getBookStores() {
        return bookStores;
    }
    public void setBookStores(ArrayList<BookStore> bookStores) {
        this.bookStores = bookStores;
        Iterator<BookStore> iterator = bookStores.iterator();
    }
    public String toString(){
        String s = "";
        s += "Name:\n "+name;
        s+= "\nBookstores:\n";
        Iterator<BookStore> iterator = bookStores.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString();
        }
        s+= "Bookreaders:\n";
        Iterator<BookReader> iterator1 = bookReaders.iterator();
        while (iterator1.hasNext()){
            s+= iterator1.next().toString();
        }
        return s;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        out.writeInt(bookReaders.size());
        for (BookReader b : bookReaders) {
            ArrayList<Book> books = b.getBooks();
            Iterator<Book> iterator = books.iterator();
            out.writeInt(books.size());
            while(iterator.hasNext()){
                Book book = iterator.next();
                out.writeObject(book.getName());
                out.writeInt(book.getYear());
                out.writeInt(book.getNumber());
                out.writeObject(book.getAuthor().getName());
                out.writeObject(book.getAuthor().getSurname());
            }
            out.writeObject(b.getName());
            out.writeObject(b.getSurname());
            out.writeInt(b.getId());
            /*out.writeInt(bookStores.getBookArrayList.size());
            for (Book b : bookArrayList) {
                out.writeObject(b.getName());
                out.writeInt(b.getYear());
                out.writeInt(b.getNumber());
                out.writeObject(b.getAuthor().getName());
                out.writeObject(b.getAuthor().getSurname());
            }*/
        }
        out.writeInt(bookStores.size());
        for (BookStore st : bookStores) {
            ArrayList<Book> books = st.getBookArrayList();
            out.writeInt(books.size());
            for (Book b : books) {
                out.writeObject(b.getName());
                out.writeInt(b.getYear());
                out.writeInt(b.getNumber());
                out.writeObject(b.getAuthor().getName());
                out.writeObject(b.getAuthor().getSurname());
            }
            out.writeObject(st.getName());
        }
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        bookReaders = new ArrayList<>();
        bookStores = new ArrayList<>();
        int size = in.readInt();
        for (int i = 0; i < size; i++) {
            int bookSize = in.readInt();
            ArrayList<Book> books = new ArrayList<>();
            for(int j =0;j<bookSize; j++){
                Book b = new Book((String)in.readObject(), in.readInt(), in.readInt(),
                        new Author((String) in.readObject(), (String) in.readObject()));
                books.add(b);
            }
            BookReader reader = new BookReader((String) in.readObject(),
                    (String) in.readObject(), in.readInt(), books);
            bookReaders.add(reader);
        }

        int storeSize = in.readInt();
        for (int i = 0; i < storeSize; i++) {
            int bookSize = in.readInt();
            ArrayList<Book> books = new ArrayList<>();
            for(int j =0;j<bookSize; j++){
                Book b = new Book((String)in.readObject(), in.readInt(), in.readInt(),
                        new Author((String) in.readObject(), (String) in.readObject()));
                books.add(b);
            }
            BookStore store = new BookStore((String) in.readObject(), books);
            bookStores.add(store);
        }

    }
}
