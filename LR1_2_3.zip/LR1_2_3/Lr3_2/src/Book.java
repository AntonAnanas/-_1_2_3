import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Book implements Serializable {
    private String name;
    private Author author;
    private int year;
    private int number;
    public Book(){
        this.name = "FFAR";
        this.year = 1964;
        this.number = 1;
        this.author = new Author("Tom", "Clancy");
    }
    public Book(String name, int year, int number, Author author){
        this.name = name;
        this.year = year;
        this.number = number;
        this.author = author;
    }
    public Author getAuthor(){
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public String toString(){
        String s = "number: ";
        s+=number;
        s+="\nname: ";
        s+=name;
        s+="\nyear: ";
        s+=year+ "\nAuthor ";
        s+= author.toString() + "\n";
        return s;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public int getYear(){
        return year;
    }
    public void setYear(int year){
        if(year<=0||year>=2021){
            System.out.println("Error!");
            return;
        }
        this.year = year;
    }
    public void setNumber(int number){
        this.number = number;
    }
    public int getNumber(){
        return number;
    }
}
