import java.io.Serializable;
import java.rmi.Naming;
import java.util.ArrayList;
import java.util.Iterator;

public class BookReader extends Human implements Serializable {
    int id;
    ArrayList<Book> books;
    public BookReader(String name, String surname, int id, ArrayList<Book> books){
        this.name = name;
        this.surname = surname;
        this.id = id;
        this.books = books;
    }
    public BookReader(){
        this.name = "Gena";
        this.surname = "Geniy";
        this.id = 2;
        this.books = new ArrayList<Book>();
        books.add(new Book());
    }
    public String toString(){
        String s = this.name + " " + this.surname + "\nid: " + id + "\nBooks: ";
        Iterator<Book> iterator = books.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString()+ "\n";
        }
        return s;
    }
    public ArrayList<Book> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<Book> books) {
        this.books = books;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getSurname(){
        return surname;
    }
    public void setSurname(String surname){
        this.surname = surname;
    }
}
