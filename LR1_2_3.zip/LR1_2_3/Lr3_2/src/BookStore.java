import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class BookStore implements Serializable {
    String name;
    ArrayList<Book> bookArrayList = new ArrayList<>();
    public BookStore(){
        this.name = "BookStore";
        this.bookArrayList.add(new Book());
        Iterator<Book> bookIterator = bookArrayList.iterator();
    }
    public String toString(){
        String s = "Name:\n " + name;
        s+= "\nBooks:\n";
        Iterator<Book> iterator = bookArrayList.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString()+ "\n";
        }
        return s;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public ArrayList<Book> getBookArrayList() {
        return bookArrayList;
    }
    public void setBookArrayList(ArrayList<Book> bookArrayList) {
        this.bookArrayList = bookArrayList;
    }
}
