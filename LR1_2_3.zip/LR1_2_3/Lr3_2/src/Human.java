import java.io.Serializable;

public abstract class Human implements Serializable {
    String name;
    String surname;
}
