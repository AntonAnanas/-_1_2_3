import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class Library implements Serializable {
    String name;
    ArrayList<BookStore> bookStores;
    ArrayList<BookReader> bookReaders;
    public Library(String name){
        this.name = name;
        this.bookStores = new ArrayList<>();
        this.bookReaders = new ArrayList<>();
    }
    public Library(String name, ArrayList<BookReader> bookReaders, ArrayList<BookStore> bookStores){
        this.bookReaders = bookReaders;
        this.bookStores = bookStores;
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public ArrayList<BookReader> getBookReaders() {
        return bookReaders;
    }
    public void setBookReaders(ArrayList<BookReader> bookReaders) {
        this.bookReaders = bookReaders;
    }
    public ArrayList<BookStore> getBookStores() {
        return bookStores;
    }
    public void setBookStores(ArrayList<BookStore> bookStores) {
        this.bookStores = bookStores;
        Iterator<BookStore> iterator = bookStores.iterator();
    }
    public String toString(){
        String s = "";
        s += "Name:\n "+name;
        s+= "\nBookstores:\n";
        Iterator<BookStore> iterator = bookStores.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString();
        }
        s+= "Bookreaders:\n";
        Iterator<BookReader> iterator1 = bookReaders.iterator();
        while (iterator1.hasNext()){
            s+= iterator1.next().toString();
        }
        return s;
    }
}
