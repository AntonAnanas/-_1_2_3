import java.io.*;

public class Author extends Human implements Externalizable {
    public Author(String name, String surname){
        this.name = name;
        this.surname = surname;
    }
    public Author(){
        this.name = "name";
        this.surname = "surname";
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getSurname(){
        return surname;
    }
    public void setSurname(String surname){
        this.surname = surname;
    }
    public String toString(){
        String s = " ";
        s+=name;
        s+=" ";
        s+=surname+ " ";
        return s;
    }
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String)in.readObject();
        surname = (String)in.readObject();
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeObject(surname);
    }
}
