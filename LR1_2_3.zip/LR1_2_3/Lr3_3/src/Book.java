import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;


public class Book implements Externalizable {
    private String name;
    private Author author;
    private int year;
    private int number;
    public Book(){
        this.name = "FFAR";
        this.year = 1964;
        this.number = 1;
        this.author = new Author("Tom", "Clancy");
    }
    public Book(String name, int year, int number, Author author){
        this.name = name;
        this.year = year;
        this.number = number;
        this.author = author;
    }
    public Author getAuthor(){
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public String toString(){
        String s = "number: ";
        s+=number;
        s+="\nname: ";
        s+=name;
        s+="\nyear: ";
        s+=year+ "\nAuthor ";
        s+= author.toString() + "\n";
        return s;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public int getYear(){
        return year;
    }
    public void setYear(int year){
        if(year<=0||year>=2021){
            System.out.println("Error!");
            return;
        }
        this.year = year;
    }
    public void setNumber(int number){
        this.number = number;
    }
    public int getNumber(){
        return number;
    }
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String)in.readObject();
        year = in.readInt();
        number = in.readInt();
        author.readExternal(in);

    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeInt(year);
        out.writeInt(number);
        author.writeExternal(out);
    }

}
