import java.io.Externalizable;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class BookReader extends Human implements Externalizable {
    int id;
    ArrayList<Book> books;
    public BookReader(String name, String surname, int id, ArrayList<Book> books){
        this.name = name;
        this.surname = surname;
        this.id = id;
        this.books = books;
    }
    public BookReader(int flag){
        this.name = "Gena";
        this.surname = "Geniy";
        this.id = 2;
        this.books = new ArrayList<Book>();
        books.add(new Book());
    }
    public BookReader(){
        this.books = new ArrayList<Book>();
    }
    public String toString(){
        String s = this.name + " " + this.surname + "\nid: " + id + "\nBooks: ";
        Iterator<Book> iterator = books.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString()+ "\n";
        }
        return s;
    }
    public ArrayList<Book> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<Book> books) {
        this.books = books;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getSurname(){
        return surname;
    }
    public void setSurname(String surname){
        this.surname = surname;
    }
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String)in.readObject();
        surname = (String)in.readObject();
        id = in.readInt();
        int count = in.readInt();
        for(int i=0; i<count; i++){
            Book ext = new Book();
            ext.readExternal(in);
            books.add(ext);
        }
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeObject(surname);
        out.writeInt(id);
        out.writeInt(books.size());
        for (Externalizable ext : books)
            ext.writeExternal(out);
    }

}
