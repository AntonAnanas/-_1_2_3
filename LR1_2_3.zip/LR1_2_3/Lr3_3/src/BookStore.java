import java.io.Externalizable;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class BookStore implements Externalizable {
    String name;
    ArrayList<Book> bookArrayList = new ArrayList<>();
    public BookStore(int flag){
        this.name = "BookStore";
        this.bookArrayList.add(new Book());
    }
    public BookStore(){}
    public String toString(){
        String s = "Name:\n " + name;
        s+= "\nBooks:\n";
        Iterator<Book> iterator = bookArrayList.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString()+ "\n";
        }
        return s;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public ArrayList<Book> getBookArrayList() {
        return bookArrayList;
    }
    public void setBookArrayList(ArrayList<Book> bookArrayList) {
        this.bookArrayList = bookArrayList;
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String)in.readObject();
        int count = in.readInt();
        for(int i=0; i<count; i++){
            Book ext = new Book();
            ext.readExternal(in);
            bookArrayList.add(ext);
        }
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeInt(bookArrayList.size());
        for (Externalizable ext : bookArrayList)
        ext.writeExternal(out);
    }
}
