import java.io.Externalizable;

public abstract class Human implements Externalizable {
    String name;
    String surname;
}
