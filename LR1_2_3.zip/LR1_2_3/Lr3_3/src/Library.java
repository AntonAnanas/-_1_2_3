import java.io.Externalizable;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Library implements Externalizable {
    String name;
    ArrayList<BookStore> bookStores;
    ArrayList<BookReader> bookReaders;
    public Library(String name){
        this.name = name;
        this.bookStores = new ArrayList<>();
        this.bookReaders = new ArrayList<>();
    }
    public Library(){
        this.bookStores = new ArrayList<>();
        this.bookReaders = new ArrayList<>();
    }
    public Library(String name, ArrayList<BookReader> bookReaders, ArrayList<BookStore> bookStores){
        this.bookReaders = bookReaders;
        this.bookStores = bookStores;
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public ArrayList<BookReader> getBookReaders() {
        return bookReaders;
    }
    public void setBookReaders(ArrayList<BookReader> bookReaders) {
        this.bookReaders = bookReaders;
    }
    public ArrayList<BookStore> getBookStores() {
        return bookStores;
    }
    public void setBookStores(ArrayList<BookStore> bookStores) {
        this.bookStores = bookStores;
        Iterator<BookStore> iterator = bookStores.iterator();
    }
    public String toString(){
        String s = "";
        s += "Name:\n "+name;
        s+= "\nBookstores:\n";
        Iterator<BookStore> iterator = bookStores.iterator();
        while (iterator.hasNext()){
            s+= iterator.next().toString();
        }
        s+= "Bookreaders:\n";
        Iterator<BookReader> iterator1 = bookReaders.iterator();
        while (iterator1.hasNext()){
            s+= iterator1.next().toString();
        }
        return s;
    }
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String)in.readObject();
        int readers = in.readInt();
        for(int i=0; i<readers; i++){
            BookReader ext = new BookReader();
            ext.readExternal(in);
            bookReaders.add(ext);
        }
        int stores = in.readInt();
        for(int i=0; i<stores; i++){
            BookStore ext = new BookStore();
            ext.readExternal(in);
            bookStores.add(ext);
        }

    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeInt(bookReaders.size());
        for (Externalizable ext : bookReaders)
            ext.writeExternal(out);
        out.writeInt(bookStores.size());
        for (Externalizable ext : bookStores)
            ext.writeExternal(out);
    }

}
