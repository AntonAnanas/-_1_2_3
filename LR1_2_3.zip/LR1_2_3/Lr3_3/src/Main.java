import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Library library = new Library("library 1");
        ArrayList<Book> books = new ArrayList<>();
        books.add(new Book("Djaba", 2007, 2, new Author("Igor", "Igorevich")));
        ArrayList<BookReader> bookreaders = new ArrayList<>();
        bookreaders.add(new BookReader("Ivan", "Ivanov", 1, books));
        bookreaders.add(new BookReader(1));
        library.setBookReaders(bookreaders);
        ArrayList<BookStore> bookStores = new ArrayList<>();
        bookStores.add(new BookStore(1));
        library.setBookStores(bookStores);
        Serialization.serializeObject("file1.dat", library);
        Library library1 = (Library) Serialization.deSerializeObject("file1.dat");
        System.out.println(library1.toString());
    }
}
